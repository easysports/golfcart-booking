#!/usr/bin/env bash
set -euo pipefail
MODE="${1:---check}"
REPO="${2:-$PWD}"
PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
EXPECTED_HEAD="60bc0d86988c350afc8ac98174aab7190a04efa6"

echo "==> ScheduleFleet 3.9E.5.17 Public Booking — Pricing Contract Repair"
echo "==> Repository: $REPO"
cd "$REPO"
[[ "$(git rev-parse HEAD)" == "$EXPECTED_HEAD" ]] || { echo "ERROR: expected HEAD $EXPECTED_HEAD"; exit 1; }
verify_baseline() {
  local failed=0
  while read -r hash file; do
    if [[ ! -f "$file" ]] || [[ "$(sha256sum "$file" | awk '{print $1}')" != "$hash" ]]; then echo "$file: FAILED"; failed=1; else echo "$file: OK"; fi
  done < "$PKG_DIR/BASELINE.sha256"
  return "$failed"
}
run_tests() {
  node test_public_pricing_contract_39e517.mjs
  python - <<'PY'
from pathlib import Path
import re, subprocess, tempfile
s=Path('index.html').read_text()
scripts=re.findall(r'<script(?:\s[^>]*)?>(.*?)</script>', s, re.S|re.I)
assert scripts
with tempfile.NamedTemporaryFile('w', suffix='.js', delete=False) as f:
    f.write('\n'.join(scripts)); name=f.name
subprocess.run(['node','--check',name], check=True)
print('PASS public booking inline JavaScript syntax')
PY
}
if [[ "$MODE" == "--check" ]]; then
  verify_baseline || { echo "ERROR: baseline hash verification failed; do not bypass"; exit 1; }
  TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
  git archive HEAD | tar -x -C "$TMP"
  cp -a "$PKG_DIR/payload/." "$TMP/"
  (cd "$TMP" && run_tests)
  echo "==> CHECK PASSED — no repository files changed."
  exit 0
fi
[[ "$MODE" == "--apply" ]] || { echo "Usage: install.sh --check|--apply [repo]"; exit 2; }
verify_baseline || { echo "ERROR: baseline hash verification failed; do not bypass"; exit 1; }
cp -a "$PKG_DIR/payload/." "$REPO/"
run_tests
echo "==> APPLY PASSED — public booking pricing contract repair installed and validated."
