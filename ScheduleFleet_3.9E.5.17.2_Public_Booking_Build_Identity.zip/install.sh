#!/usr/bin/env bash
set -Eeuo pipefail
MODE="${1:---check}"
REPO="${2:-$PWD}"
PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
EXPECTED_HEAD_SHORT="e67db1c"
PATCH_NAME="ScheduleFleet 3.9E.5.17.2 Public Booking — Build Identity"

fail(){ printf '\nERROR: %s\n' "$*" >&2; exit 1; }
info(){ printf '\n==> %s\n' "$*"; }
file_sha(){ sha256sum "$1" | awk '{print $1}'; }

[[ "$MODE" == "--check" || "$MODE" == "--apply" ]] || fail "Usage: $0 --check|--apply [repo]"
info "$PATCH_NAME"
info "Repository: $REPO"
cd "$REPO"

baseline_matches(){
  local failed=0 hash file
  while read -r hash file; do
    [[ -n "${file:-}" ]] || continue
    if [[ ! -f "$file" || "$(file_sha "$file")" != "$hash" ]]; then echo "$file: FAILED"; failed=1; else echo "$file: OK"; fi
  done < "$PKG_DIR/BASELINE.sha256"
  while IFS= read -r file; do
    [[ -n "$file" ]] || continue
    if [[ -e "$file" ]]; then echo "$file: UNEXPECTEDLY PRESENT"; failed=1; else echo "$file: absent as expected"; fi
  done < "$PKG_DIR/BASELINE.absent"
  return "$failed"
}

payload_matches(){
  local hash file
  while read -r hash file; do
    [[ -f "$file" ]] || return 1
    [[ "$(file_sha "$file")" == "$hash" ]] || return 1
  done < "$PKG_DIR/PAYLOAD.sha256"
}
copy_payload(){ (cd "$PKG_DIR/payload" && tar -cf - .) | (cd "$1" && tar -xf -); }

validate(){
  local target="$1"
  (
    cd "$target"
    for test_file in test_*.mjs; do node "$test_file"; done
    node --check buildIdentity39E5172.js
    node --check checkoutStateIntegrity39E5171.js
    python - <<'PY'
from pathlib import Path
import os, re, subprocess, tempfile
html = Path('index.html').read_text()
scripts = re.findall(r'<script(?:\s[^>]*)?>(.*?)</script>', html, re.S | re.I)
assert scripts, 'no inline JavaScript found'
fd, name = tempfile.mkstemp(suffix='.js'); os.close(fd)
try:
    Path(name).write_text('\n'.join(scripts))
    subprocess.run(['node', '--check', name], check=True)
finally:
    Path(name).unlink(missing_ok=True)
print('PASS public booking inline JavaScript syntax')
PY
    grep -q 'schedulefleet-public-version" content="3.9E.5.17.2"' index.html
    grep -q 'Booking v3.9E.5.17.2' index.html
  )
}

if payload_matches; then
  info "Exact payload already installed."
  validate "$REPO"
  exit 0
fi

[[ "$(git branch --show-current)" == "main" ]] || fail "Expected branch main"
[[ "$(git rev-parse --short=7 HEAD)" == "$EXPECTED_HEAD_SHORT" ]] || fail "Expected HEAD $EXPECTED_HEAD_SHORT; do not bypass"
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail "Tracked tree is not clean"
info "Verifying exact e67db1c source baseline"
baseline_matches || fail "Baseline hash verification failed; do not bypass"

info "Testing detached copy"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
git archive HEAD | tar -x -C "$TMP"
copy_payload "$TMP"
validate "$TMP"

if [[ "$MODE" == "--check" ]]; then
  info "CHECK PASSED — no repository files changed."
  exit 0
fi

info "Applying payload"
copy_payload "$REPO"
rollback=1
on_exit(){
  local rc=$?
  if [[ $rc -ne 0 && ${rollback:-0} -eq 1 ]]; then
    git restore -- index.html test_checkout_state_integrity_39e5171.mjs test_public_pricing_contract_39e517.mjs || true
    rm -f buildIdentity39E5172.js test_build_identity_39e5172.mjs
  fi
  rm -rf "$TMP"
  exit "$rc"
}
trap on_exit EXIT
payload_matches || fail "Applied payload checksum verification failed"
validate "$REPO"
git diff --check
rollback=0
trap - EXIT
rm -rf "$TMP"
info "APPLY PASSED — visible booking build identity installed and validated."
