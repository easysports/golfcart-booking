#!/usr/bin/env bash
set -euo pipefail
MODE="${1:---check}"
REPO="${2:-$PWD}"
PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
EXPECTED_HEAD="0919200a7bd663ef6fc08c57efe9c080dfa7823b"

say() { printf '%s\n' "$*"; }
file_sha() { sha256sum "$1" | awk '{print $1}'; }

say "==> ScheduleFleet 3.9E.5.17.1 Public Booking — Checkout State Integrity"
say "==> Repository: $REPO"
cd "$REPO"
[[ "$(git rev-parse HEAD)" == "$EXPECTED_HEAD" ]] || { say "ERROR: expected HEAD $EXPECTED_HEAD"; exit 1; }

baseline_matches() {
  local failed=0 hash file
  while read -r hash file; do
    [[ -n "${file:-}" ]] || continue
    if [[ ! -f "$file" ]] || [[ "$(file_sha "$file")" != "$hash" ]]; then
      say "$file: FAILED"
      failed=1
    else
      say "$file: OK"
    fi
  done < "$PKG_DIR/BASELINE.sha256"
  while IFS= read -r file; do
    [[ -n "$file" ]] || continue
    if [[ -e "$file" ]]; then
      say "$file: UNEXPECTEDLY PRESENT"
      failed=1
    else
      say "$file: absent as expected"
    fi
  done < "$PKG_DIR/BASELINE.absent"
  return "$failed"
}

payload_matches() {
  local failed=0 hash file
  while read -r hash file; do
    [[ -n "${file:-}" ]] || continue
    if [[ ! -f "$file" ]] || [[ "$(file_sha "$file")" != "$hash" ]]; then
      failed=1
    fi
  done < "$PKG_DIR/PAYLOAD.sha256"
  return "$failed"
}

source_state() {
  if baseline_matches >/dev/null 2>&1; then echo baseline; return 0; fi
  if payload_matches; then echo payload; return 0; fi
  return 1
}

verify_source_state() {
  local state
  state="$(source_state || true)"
  if [[ "$state" == "baseline" ]]; then
    baseline_matches
    say "Source state: exact 0919200 baseline"
  elif [[ "$state" == "payload" ]]; then
    say "Source state: exact 3.9E.5.17.1 payload already applied"
  else
    baseline_matches || true
    say "ERROR: source is neither the accepted baseline nor the exact patch payload; do not bypass"
    exit 1
  fi
  printf '%s' "$state"
}

run_tests() {
  node test_public_pricing_contract_39e517.mjs
  node test_checkout_state_integrity_39e5171.mjs
  node test_checkout_state_runtime_39e5171.mjs
  node --check checkoutStateIntegrity39E5171.js
  python - <<'PY'
from pathlib import Path
import os, re, subprocess, tempfile
html = Path('index.html').read_text()
scripts = re.findall(r'<script(?:\s[^>]*)?>(.*?)</script>', html, re.S | re.I)
assert scripts, 'no inline JavaScript found'
fd, name = tempfile.mkstemp(suffix='.js')
os.close(fd)
try:
    Path(name).write_text('\n'.join(scripts))
    subprocess.run(['node', '--check', name], check=True)
finally:
    Path(name).unlink(missing_ok=True)
print('PASS public booking inline JavaScript syntax')
PY
}

STATE="$(verify_source_state | tail -n 1)"

if [[ "$MODE" == "--check" ]]; then
  if [[ "$STATE" == "baseline" ]]; then
    TMP="$(mktemp -d)"
    trap 'rm -rf "$TMP"' EXIT
    git archive HEAD | tar -x -C "$TMP"
    cp -a "$PKG_DIR/payload/." "$TMP/"
    (cd "$TMP" && run_tests)
  else
    run_tests
  fi
  say "==> CHECK PASSED — no repository files changed."
  exit 0
fi

[[ "$MODE" == "--apply" ]] || { say "Usage: install.sh --check|--apply [repo]"; exit 2; }
if [[ "$STATE" == "baseline" ]]; then
  cp -a "$PKG_DIR/payload/." "$REPO/"
fi
payload_matches || { say "ERROR: applied payload checksum verification failed"; exit 1; }
run_tests
say "==> APPLY PASSED — stale checkout sessions, summaries, availability, and policy acknowledgements now fail closed after material changes."
